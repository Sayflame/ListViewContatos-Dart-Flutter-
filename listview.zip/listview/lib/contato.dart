class Contato{
  String nome;
  String email;


  Contato(this.nome, this.email);


}

class ContatoLista{
    List<Contato> contatos = [
    Contato("Abi", "A@gmail.com"),
    Contato("Bab", "B@gmail.com"),
    Contato("Char", "C@gmail.com"),
    Contato("Daki", "D@gmail.com")
  ];
}